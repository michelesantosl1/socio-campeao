<template>
    <div class="">
        <div class="titulo">
            <h1>Sócios Plano X</h1>
        </div>
    </div>
</template>

<script></script>

<style></style>